package com.example.microsoft.getstartednh;

/**
 * Created by Wesley on 7/1/2016.
 */
public class NotificationSettings {

    public static String SenderId = "136925468983";
    public static String HubName = "getstartednhnotificationhub";
    public static String HubListenConnectionString = "Endpoint=sb://getstartednhnotificationhubnamespace1.servicebus.windows.net/;SharedAccessKeyName=DefaultListenSharedAccessSignature;SharedAccessKey=wZ4T1nuGf12zbMSXlEl/lLNXERCFutMTjYL+qLZ6xAI=";
    public static String HubFullAccess = "Endpoint=sb://getstartednhnotificationhubnamespace1.servicebus.windows.net/;SharedAccessKeyName=DefaultFullSharedAccessSignature;SharedAccessKey=H5oxdYbcyU33IdBu49lygb1FsCA9LMi4FPU5JC+Jtso=";
}
