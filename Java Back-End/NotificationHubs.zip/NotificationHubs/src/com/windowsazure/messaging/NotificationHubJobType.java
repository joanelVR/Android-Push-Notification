package com.windowsazure.messaging;

public enum NotificationHubJobType {
	ExportRegistrations,
	ImportCreateRegistrations,
	ImportUpdateRegistrations,
	ImportDeleteRegistrations
}
