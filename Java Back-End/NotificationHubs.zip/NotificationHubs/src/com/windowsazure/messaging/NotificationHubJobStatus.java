package com.windowsazure.messaging;

public enum NotificationHubJobStatus {
	Started,
	Running,
	Completed,
	Failed
}
