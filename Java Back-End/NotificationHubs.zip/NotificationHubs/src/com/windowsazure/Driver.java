package com.windowsazure;

import com.windowsazure.messaging.Notification;
import com.windowsazure.messaging.NotificationHub;
import com.windowsazure.messaging.NotificationHubsException;

public class Driver {
	
	public static void main(String[] args) {
		
		//FOR IOS
		/**
		//DefaultFullSharedAccessSignature string (2nd String) from Azure Notification Hub
		String CONNECTION = "Endpoint=sb://iosnotificationhubnamespace1.servicebus.windows.net/;SharedAccessKeyName=DefaultFullSharedAccessSignature;SharedAccessKey=0aEVT0LGgPPqqoykw1eMCfXExKJxGMArHhkAjUKQLyg=";
		
		 //Initialize your Notification Hubs client
	 // NotificationHub hub = new NotificationHub("{connection string}", "{hubname}");
		NotificationHub hub = new NotificationHub(CONNECTION,"iosnotificationhub");
		
		//FOR IOS
		String alert = "{\"aps\":{\"alert\":\"Hello from Java!\"}}";
		Notification n = Notification.createAppleNotification(alert);
		
		try {
			hub.sendNotification(n);
		} catch (NotificationHubsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		**/
		
		//FOR ANDROID
		//DefaultFullSharedAccessSignature string (2nd String) from Azure Notification Hub
				String CONNECTION = "Endpoint=sb://getstartednhnotificationhubnamespace1.servicebus.windows.net/;SharedAccessKeyName=DefaultFullSharedAccessSignature;SharedAccessKey=H5oxdYbcyU33IdBu49lygb1FsCA9LMi4FPU5JC+Jtso=";
				
				 //Initialize your Notification Hubs client
			 // NotificationHub hub = new NotificationHub("{connection string}", "{hubname}");
				NotificationHub hub = new NotificationHub(CONNECTION,"getstartednhnotificationhub");
				
				//FOR IOS
				String message = "{\"data\":{\"message\":\"INFOSYS RUL3Z\"}}";
				Notification n = Notification.createGcmNotifiation(message);
				
				try {
					hub.sendNotification(n);
					System.out.println("Send successfully");
				} catch (NotificationHubsException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	}
}
